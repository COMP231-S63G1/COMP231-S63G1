<?php

/**
 * Database config variables
 
*/

define("DB_HOST", "107.180.0.218");

define("DB_USER", "wanna");

define("DB_PASSWORD", "1stAPPWanna!");

define("DB_DATABASE", "wanna");

?>